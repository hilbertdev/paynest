# Capstone rubrics (mirror)

These files mirror the **grading criteria** in [docs/assessments/](../assessments/README.md) and the workbook [Capstones (2).xlsx](../Capstones%20(2).xlsx).

- Use the **assessment briefs** for full scenarios, deliverables, and business rules.
- Use **CSV files here** or the **Excel workbook** for scoring during review.

Each `capstone-0N-rubric.csv` has columns: Criterion, Weight hint, Level 1–4.
